package com.mycompany.quickchatapp;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {
    
    Login login = new Login("Sam", "Smith");
    
    @Test public void testUsernameCorrectly() { assertTrue(login.checkUserName("Sam_1")); }
    @Test public void testUsernameIncorrectly() { assertFalse(login.checkUserName("Sam!!!!!!!")); }
    @Test public void testPasswordMeetsComplexity() { assertTrue(login.checkPasswordComplexity("Ph&&sec@ke55!!")); }
    @Test public void testPasswordDoesNotMeetComplexity() { assertFalse(login.checkPasswordComplexity("password")); }
    @Test public void testCellPhoneCorrectlyFormatted() { assertTrue(login.checkCellPhoneNumber("+27867890987")); }
    @Test public void testCellPhoneIncorrectlyFormatted() { assertFalse(login.checkCellPhoneNumber("0765436778")); }
    @Test public void testLoginSuccessful() {  login.registerUser("Sam_1", "Ph&&sec@ke55!!", "+27867890987"); 
       boolean result= login.loginUser("Sam_1", "Ph&&sec@ke55!!"); 
         assertTrue(result);}
    @Test public void testLoginFailed() { login.registerUser("Sam_1", "Ph&&sec@ke55!!", "+27867890987"); 
    boolean result = login.loginUser("Sam_1", "wrongpass");
    assertFalse(result);
    }    
}