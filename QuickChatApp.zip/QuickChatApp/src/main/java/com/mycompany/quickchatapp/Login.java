package com.mycompany.quickchatapp;

public class Login{
    String username;
    String password;
    String cellNumber;
    String firstName;
    String lastName;
    
    public Login(String firstName, String lastName){
        this.firstName = firstName;
        this.lastName = lastName;
    }
    
    public boolean checkUserName(String username){
        if (username.contains("_") && username.length() <=5) {
            return true;
        } else {
            return false;
        }
    }
    
    public boolean checkPasswordComplexity(String password) {
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        
        if (password.length() < 8) {
            return false;
        }
        
        for (int i = 0; i <password.length(); i++) {
            char c =password.charAt(i);
               if(Character.isUpperCase(c)) hasCapital = true;
               if (Character.isDigit(c)) hasNumber = true;
               if (!Character.isLetterOrDigit(c)) hasSpecial =true;
        }
        
        return hasCapital && hasNumber && hasSpecial;
    }
    
    public boolean checkCellPhoneNumber(String cellNumber) {
        if (cellNumber.length() == 12 && cellNumber.startsWith("+27")) {
            for (int i = 3; i < cellNumber.length(); i++){
                if (!Character.isDigit(cellNumber.charAt(i))) return false;
            }
            return true;
        }
        return false;
    }
    
    public String registerUser(String username, String password, String cellNumber) {
        this.username = username;
        this.password = password;
        this.cellNumber = cellNumber;
        
        if (!checkUserName(username))
        {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(cellNumber)) {
            return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }
            return "The two above conditions have been met, and the user has been registered successfully.";
    }
    
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return enteredUsername.equals(this.username) && enteredPassword.equals(this.password);
    }
    
    public String returnLoginStatus(String enteredUsername, String enteredPassword) {
        if (loginUser(enteredUsername, enteredPassword)) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again";
        }else{
            return "Username or password incorrect, please try again.";
        }
    }
}