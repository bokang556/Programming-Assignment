package com.mycompany.quickchatapp;

import  java.util.Scanner;

public class QuickChatApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login("", "");
        System.out.println("=== Registration ===");
        System.out.println("Enter First Name: ");
        String firstName =scanner.nextLine();
        System.out.println("Enter Last Name: ");
        String lastName = scanner.nextLine();
        login = new Login(firstName, lastName);
        System.out.println("Enter Username: ");
        String username = scanner.nextLine();
        System.out.println("Enter Password: ");
        String password = scanner.nextLine();
        System.out.println("Enter Cell Number: ");
        String cellNumber = scanner.nextLine();
        String regMessage =login.registerUser(username, password, cellNumber);
        System.out.println(regMessage);
        if(regMessage.contains("successfully")){
            System.out.println("\n=== Login ===");
            System.out.println("Enter Username: ");
            String loginUsername = scanner.nextLine();
            System.out.println("Enter Password");
            String loginPassword = scanner.nextLine();
            boolean loggedIn = login.loginUser(loginUsername, loginPassword);   
           System.out.println(login.returnLoginStatus(loginUsername, loginPassword));
        }
    }
}