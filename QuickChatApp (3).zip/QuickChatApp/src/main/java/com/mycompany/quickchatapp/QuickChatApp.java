package com.mycompany.quickchatapp;

import java.util.Scanner;

public class QuickChatApp {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Login login = new Login("", "");

        String[] sentMessages = new String[10];
        String[] disregardedMessages = new String[10];
        String[] storedMessages = new String[10];
        String[] messageHashes = new String[10];
        String[] messageIDs = new String[10];
        String[] senders = new String[10];
        String[] recipients = new String[10];

        int sentCount = 0;
        int disregardedCount = 0;
        int storedCount = 0;

        storedMessages[0] = "Did you get the cake?";
        messageIDs[0] = "1";
        messageHashes[0] = ":10:Did you get the cake?";
        senders[0] = "0838884567";
        recipients[0] = "+27831234567";

        storedMessages[1] = "Where are you?";
        messageIDs[1] = "2";
        messageHashes[1] = ":10:Where are you?";
        senders[1] = "0838884567";
        recipients[1] = "+27831234567";

        storedMessages[2] = "How is your homework going?";
        messageIDs[2] = "3";
        messageHashes[2] = ":10:How is your homework going?";
        senders[2] = "0838884567";
        recipients[2] = "+27831234567";

        storedMessages[3] = "I am going to study.";
        messageIDs[3] = "4";
        messageHashes[3] = ":10:I am going to study.";
        senders[3] = "0838884567";
        recipients[3] = "+27831234567";

        storedMessages[4] = "The Avengers movie was awesome.";
        messageIDs[4] = "5";
        messageHashes[4] = ":10:The Avengers movie was awesome.";
        senders[4] = "0838884567";
        recipients[4] = "+27831234567";

        storedCount = 5;

        System.out.println("===== Registration =====");
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();
        System.out.print("Enter Cell Number: ");
        String cellNumber = scanner.nextLine();

        String regMessage = login.registerUser(username, password, cellNumber);
        System.out.println(regMessage);

        if (regMessage.contains("successfully")) {

            System.out.println("\n=== Login ===");
            System.out.print("Enter Username: ");
            String loginUsername = scanner.nextLine();
            System.out.print("Enter Password: ");
            String loginPassword = scanner.nextLine();

            boolean loggedIn = login.loginUser(loginUsername, loginPassword);
            System.out.println(login.returnLoginStatus(loginUsername, loginPassword));

            if (loggedIn) {

                System.out.println("Welcome to QuickChat.");
                System.out.print("How many messages do you wish to enter? ");
                int numMessages = Integer.parseInt(scanner.nextLine());

                for (int i = 0; i < numMessages; i++) {

                    Message msg = new Message();
                    msg.setNumMessages(i + 1);

                    System.out.print("Enter recipient (e.g. +27718693002): ");
                    String recipient = scanner.nextLine();
                    msg.setRecipient(recipient);

                    if (!msg.checkRecipientCell()) {
                        System.out.println("Cell phone number is incorrectly captured.");
                        i--;
                        continue;
                    } else {
                        System.out.println("Cell phone number successfully captured.");
                    }

                    System.out.print("Enter your message (max 250 chars): ");
                    String messageText = scanner.nextLine();
                    msg.setMessage(messageText);

                    if (msg.checkMessageLength().equals("Message ready to send.")) {
                        System.out.println("Message ready to send.");
                    } else {
                        System.out.println("Message exceeds 250 characters. Please re-enter.");
                        i--;
                        continue;
                    }

                    String messageID = String.valueOf((long) (Math.random() * 1000000000L));
                    if (messageID.length() > 10) {
                        messageID = messageID.substring(0, 10);
                    }
                    msg.setMessageID(messageID);

                    System.out.println("Choose: 1) Send 2) Disregard 3) Store");
                    int choice = Integer.parseInt(scanner.nextLine());
                    System.out.println("Choice saved:" +(choice));

                    if (choice == 1) {
                        sentCount++;
                    } else if (choice == 2) {
                        disregardedCount++;
                    } else if (choice == 3) {
                        if (storedCount < storedMessages.length) {
                            storedMessages[storedCount] = messageText;
                            messageIDs[storedCount] = messageID;
                            messageHashes[storedCount] = msg.createMessageHash();
                            senders[storedCount] = "083 123 4567";
                            recipients[storedCount] = recipient;
                            storedCount++;
                            System.out.println("Message stored successfully.");
                        } else {
                            System.out.println("Storage full.");
                        }
                    }
                }

                System.out.println("Total messages sent: " + sentCount);
                System.out.println("\n===== Stored Messages =====");
                System.out.println("a) Display stored messages");
                System.out.println("b) Display longest stored message");
                System.out.println("c) Search for message ID");
                System.out.println("d) Search for recipient");
                System.out.println("e) Delete message using message ID");
                System.out.println("r) Display report");
                System.out.print("Choose (a-r): ");
                String menuChoice = scanner.nextLine();

                if (menuChoice.equals("a")) {

                    for (int i = 0; i < storedCount; i++) {
                        System.out.println("\nMessage " + (i + 1) + ":");
                        System.out.println("Message ID: " + messageIDs[i]);
                        System.out.println("Message Hash: " + messageHashes[i]);
                        System.out.println("Recipient: " + recipients[i]);
                        System.out.println("Message: " + storedMessages[i]);
                    }

                } else if (menuChoice.equals("b")) {

                    int longestIndex = 0;
                    for (int i = 1; i < storedCount; i++) {
                        if (storedMessages[i].length() > storedMessages[longestIndex].length()) {
                            longestIndex = i;
                        }
                    }
                    if (storedCount > 0) {
                        System.out.println("Longest message: " + storedMessages[longestIndex]);
                        System.out.println("Recipient: " + recipients[longestIndex]);
                    }

                } else if (menuChoice.equals("c")) {

                    System.out.print("Enter Message ID to search: ");
                    String searchID = scanner.nextLine();
                    boolean found = false;

                    for (int i = 0; i < storedCount; i++) {
                        if (messageIDs[i].equals(searchID)) {
                            System.out.println("Recipient: " + recipients[i]);
                            System.out.println("Message: " + storedMessages[i]);
                            found = true;
                        }
                    }
                    if (!found) {
                        System.out.println("Message ID not found.");
                    }

                } else if (menuChoice.equals("d")) {

                    System.out.print("Enter recipient to search: ");
                    String searchRecipient = scanner.nextLine();

                    for (int i = 0; i < storedCount; i++) {
                        if (recipients[i].equals(searchRecipient)) {
                            System.out.println("Message ID: " + messageIDs[i]);
                            System.out.println("Message: " + storedMessages[i]);
                        }
                    }

                } else if (menuChoice.equals("e")) {

                    System.out.print("Enter Message ID to delete: ");
                    String deleteID = scanner.nextLine();

                    for (int i = 0; i < storedCount; i++) {
                        if (messageIDs[i].equals(deleteID)) {
                            storedMessages[i] = storedMessages[storedCount - 1];
                            messageIDs[i] = messageIDs[storedCount - 1];
                            messageHashes[i] = messageHashes[storedCount - 1];
                            senders[i] = senders[storedCount - 1];
                            recipients[i] = recipients[storedCount - 1];
                            storedCount--;
                            System.out.println("Message deleted: " + deleteID);
                            break;
                        }
                    }

                } else if (menuChoice.equals("r")) {

                    System.out.println("===== Report =====");
                    for (int i = 0; i < storedCount; i++) {
                        System.out.println(messageIDs[i] + " | " + recipients[i] + " | " + messageHashes[i]);
                    }
                }
            }
        }

        scanner.close();
    }
}