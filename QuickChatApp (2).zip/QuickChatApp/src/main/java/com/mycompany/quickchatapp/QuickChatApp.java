package com.mycompany.quickchatapp;

import java.util.Scanner;

public class QuickChatApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login("", "");
        
        System.out.println("==== Registration ====");
        System.out.println("Enter First Name: ");
        String firstName = scanner.nextLine();
        System.out.println("Enter Last Name: ");
        String lastName = scanner.nextLine();
        login = new Login(firstName, lastName);
        System.out.println("Enter Username: ");
        String username = scanner.nextLine();
        System.out.println("Enter Password: ");
        String password = scanner.nextLine();
        System.out.println("Enter Cell Number: ");
        String cellNumber = scanner.nextLine();
        String regMessage = login.registerUser(username, password, cellNumber);
        System.out.println(regMessage);
        
        if (regMessage.contains("successfully")) {
            System.out.println("\n=== Login ===");
            System.out.println("Enter Username: ");
            String loginUsername = scanner.nextLine();
            System.out.println("Enter Password: ");
            String loginPassword = scanner.nextLine();
            boolean loggedIn = login.loginUser(loginUsername, loginPassword);
            System.out.println(login.returnLoginStatus(loginUsername, loginPassword));
            
            if (loggedIn) {
                System.out.println("Welcome to QuickChat.");
                System.out.println("How many messages do you wish to enter?");
                int numMessages = Integer.parseInt(scanner.nextLine());
                int sentCount = 0;
                
                for (int i = 0; i < numMessages; i++) {
                    Message msg = new Message();
                    msg.setNumMessages(i + 1);
                    
                    System.out.println("Enter recipient (e.g. +27718693002):");
                    String recipient = scanner.nextLine();
                    msg.setRecipient(recipient);
                    
                    if (!msg.checkRecipientCell()) {
                        System.out.println("Cell phone number is incorrectly captured");
                        i--;
                        continue;
                    } else {
                        System.out.println("Cell phone number successfully captured.");
                    }
                    
                    System.out.println("Enter your message (max 250 chars):");
                    String messageText = scanner.nextLine();
                    msg.setMessage(messageText);
                    
                    if (!msg.checkMessageLength().equals("Message ready to send.")) {
                        System.out.println("Message exceeds 250 characters. Please re-enter.");
                        i--;
                        continue;
                    }
                    
                    String messageID = String.valueOf((long)(Math.random() * 10000000000L));
                    if (messageID.length() > 10) messageID = messageID.substring(0, 10);
                    msg.setMessageID(messageID);
                    
                    System.out.println("Choose: 1) Send 2) Disregard 3) Store");
                    int choice = Integer.parseInt(scanner.nextLine());
                    System.out.println(msg.SentMessage(choice));
                    
                    if (choice == 1) {
                        sentCount++;
                        System.out.println("Message ID: " + msg.getMessageID());
                        System.out.println("Hash: " + msg.createMessageHash());
                    }
                }
                System.out.println("Total messages sent: " + sentCount);
            }
        }
        scanner.close();
    }
}