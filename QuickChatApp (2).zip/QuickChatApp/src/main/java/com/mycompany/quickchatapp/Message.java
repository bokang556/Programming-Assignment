package com.mycompany.quickchatapp;

import java.io.FileWriter;
import java.io.IOException;

public class Message {
    private String messageID;
    private int numMessages;
    private String recipient;
    private String message;
    private String messageHash;
    private static int totalMessages = 0;

    public Message() {}

    public String getMessageID() { return messageID; }
    public void setMessageID(String messageID) { this.messageID = messageID; }
    
    public int getNumMessages() { return numMessages; }
    public void setNumMessages(int numMessages) { this.numMessages = numMessages; }
    
    public String getRecipient() { return recipient; }
    public void setRecipient(String recipient) { this.recipient = recipient; }
    
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    
    public static int returnTotalMessages() { return totalMessages; }

    public boolean checkRecipientCell() {
        if (recipient == null) return false;
        if (!recipient.startsWith("+")) return false;
        if (recipient.length() > 13) return false;
        return true;
    }

    public String checkMessageLength() {
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            return "Message exceeds 250 characters, please reduce size.";
        }
    }

    public String createMessageHash() {
        String[] words = message.trim().split("\\s+");
        String first = words[0];
        String last = words.length > 1 ? words[words.length-1] : first;
        if (messageID == null || messageID.length() < 2) messageID = "00" + (int)(Math.random()*100000000);
        String idPart = messageID.substring(0,2);
        messageHash = (idPart + ":" + numMessages + ":" + first + last).toUpperCase();
        return messageHash;
    }

    public String SentMessage(int choice) {
        if (choice == 1) {
            totalMessages++;
            return "Message successfully sent.";
        } else if (choice == 2) {
            return "Press 0 to delete message.";
        } else if (choice == 3) {
            storeMessage();
            return "Message successfully stored.";
        } else {
            return "Invalid choice.";
        }
    }

    public void storeMessage() {
        try (FileWriter file = new FileWriter("storedMessages.txt", true)) {
            file.write("ID:" + messageID + " To:" + recipient + " Msg:" + message + " Hash:" + messageHash + "\n");
        } catch (IOException e) {
            System.out.println("Error storing");
        }
    }
}
